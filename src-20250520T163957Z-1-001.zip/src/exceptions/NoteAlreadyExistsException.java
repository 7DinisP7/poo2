package exceptions;

public class NoteAlreadyExistsException extends Exception {
    public NoteAlreadyExistsException() {
        super();
    }
}
