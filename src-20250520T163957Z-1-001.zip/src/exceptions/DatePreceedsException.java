package exceptions;

public class DatePreceedsException extends Exception {

    public DatePreceedsException() {
        super();
    }
}
