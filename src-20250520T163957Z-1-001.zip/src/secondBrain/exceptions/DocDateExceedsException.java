package secondBrain.exceptions;

public class DocDateExceedsException extends Exception {

    public DocDateExceedsException() {
        super();
    }
}
