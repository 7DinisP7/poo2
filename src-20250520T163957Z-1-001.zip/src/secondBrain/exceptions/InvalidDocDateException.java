package secondBrain.exceptions;

public class InvalidDocDateException extends Exception {

    public InvalidDocDateException() {
        super();
    }
}
