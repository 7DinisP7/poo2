package secondBrain.exceptions;

public class NoteDoesntExistException extends Exception {

    public NoteDoesntExistException() {
        super();
    }
}
