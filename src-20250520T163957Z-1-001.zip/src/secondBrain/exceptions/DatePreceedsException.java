package secondBrain.exceptions;

public class DatePreceedsException extends Exception {

    public DatePreceedsException() {
        super();
    }
}
