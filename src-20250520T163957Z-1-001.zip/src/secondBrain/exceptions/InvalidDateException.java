package secondBrain.exceptions;

public class InvalidDateException extends Exception {

    public InvalidDateException() {
        super();
    }
}
