package secondBrain;

public interface SecondBrain {
}
